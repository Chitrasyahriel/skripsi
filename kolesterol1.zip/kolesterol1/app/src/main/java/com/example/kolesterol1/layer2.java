package com.example.kolesterol1;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.soundcloud.android.crop.Crop;

public class layer2 extends AppCompatActivity {
    Button kamera1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layer2);

    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layer2);
        Button btn=(ImageButton)findViewById(R.id.irismata);
        btn.setOnClickListener(mClickListener);
    }
    View.OnClickListener mClickListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(layer2.this,"Entered in On ClickListener",Toast.LENGTH_LONG).show();
            Intent mintent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(mintent);
        }
    };
}

